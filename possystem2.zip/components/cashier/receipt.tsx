"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Printer, Share, Check } from "lucide-react"

interface ReceiptItem {
  id: number
  name: string
  quantity: number
  price: number
  total: number
}

interface ReceiptProps {
  receiptNumber: string
  items: ReceiptItem[]
  totalAmount: number
  paymentMethod: "cash" | "cashless"
  cashReceived?: number
  changeAmount?: number
  cashierName: string
  timestamp: Date
  onPrint: () => void
  onNewTransaction: () => void
}

export function Receipt({
  receiptNumber,
  items,
  totalAmount,
  paymentMethod,
  cashReceived,
  changeAmount,
  cashierName,
  timestamp,
  onPrint,
  onNewTransaction,
}: ReceiptProps) {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(price)
  }

  const formatDateTime = (date: Date) => {
    return new Intl.DateTimeFormat("id-ID", {
      dateStyle: "medium",
      timeStyle: "short",
    }).format(date)
  }

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Struk ${receiptNumber}`,
          text: `Transaksi berhasil - Total: ${formatPrice(totalAmount)}`,
        })
      } catch (error) {
        console.log("Error sharing:", error)
      }
    }
  }

  return (
    <div className="space-y-6">
      {/* Success Message */}
      <Card className="border-green-500/20 bg-green-500/5">
        <CardContent className="p-6">
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center w-16 h-16 bg-green-500/10 rounded-full mx-auto">
              <Check className="w-8 h-8 text-green-500" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-green-500">Pembayaran Berhasil!</h2>
              <p className="text-muted-foreground">Transaksi telah selesai diproses</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Receipt */}
      <Card>
        <CardHeader>
          <CardTitle className="text-center">
            <div className="space-y-2">
              <h3 className="text-lg">TOKO SERBAGUNA</h3>
              <p className="text-sm text-muted-foreground font-normal">Jl. Contoh No. 123, Jakarta</p>
              <p className="text-sm text-muted-foreground font-normal">Telp: (021) 1234-5678</p>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Separator />

          {/* Transaction Info */}
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span>No. Struk:</span>
              <span className="font-mono">{receiptNumber}</span>
            </div>
            <div className="flex justify-between">
              <span>Tanggal:</span>
              <span>{formatDateTime(timestamp)}</span>
            </div>
            <div className="flex justify-between">
              <span>Kasir:</span>
              <span>{cashierName}</span>
            </div>
            <div className="flex justify-between">
              <span>Pembayaran:</span>
              <Badge variant={paymentMethod === "cash" ? "default" : "secondary"}>
                {paymentMethod === "cash" ? "Tunai" : "Non-Tunai"}
              </Badge>
            </div>
          </div>

          <Separator />

          {/* Items */}
          <div className="space-y-3">
            {items.map((item) => (
              <div key={item.id} className="space-y-1">
                <div className="flex justify-between">
                  <span className="font-medium">{item.name}</span>
                  <span>{formatPrice(item.total)}</span>
                </div>
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>
                    {item.quantity} x {formatPrice(item.price)}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <Separator />

          {/* Totals */}
          <div className="space-y-2">
            <div className="flex justify-between font-bold text-lg">
              <span>TOTAL:</span>
              <span>{formatPrice(totalAmount)}</span>
            </div>

            {paymentMethod === "cash" && cashReceived && (
              <>
                <div className="flex justify-between text-sm">
                  <span>Uang Diterima:</span>
                  <span>{formatPrice(cashReceived)}</span>
                </div>
                {changeAmount && changeAmount > 0 && (
                  <div className="flex justify-between text-sm">
                    <span>Kembalian:</span>
                    <span>{formatPrice(changeAmount)}</span>
                  </div>
                )}
              </>
            )}
          </div>

          <Separator />

          <div className="text-center text-sm text-muted-foreground">
            <p>Terima kasih atas kunjungan Anda!</p>
            <p>Barang yang sudah dibeli tidak dapat dikembalikan</p>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <Button onClick={onPrint} variant="outline" className="touch-target bg-transparent">
          <Printer className="w-4 h-4 mr-2" />
          Cetak Struk
        </Button>

        <Button onClick={handleShare} variant="outline" className="touch-target bg-transparent">
          <Share className="w-4 h-4 mr-2" />
          Bagikan
        </Button>

        <Button onClick={onNewTransaction} className="touch-target">
          Transaksi Baru
        </Button>
      </div>
    </div>
  )
}
